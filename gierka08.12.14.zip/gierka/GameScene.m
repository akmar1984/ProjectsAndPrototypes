//
//  GameScene.m
//  gierka
//
//  Created by Marek Tomaszewski on 27/10/2014.
//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import "GameScene.h"
@interface GameScene ()

@property SKSpriteNode *carillon;
@property SKSpriteNode *clockHand1;
@property SKSpriteNode *clockHand2;
@property SKSpriteNode *biedrona;
@property SKSpriteNode *biedrona1;
@property SKEmitterNode *trail;
@property SKNode *player;

#pragma mark Zabawki
@property SKSpriteNode *misiu;
@property SKSpriteNode *pilka;
@property SKSpriteNode *pudlo;
@property SKSpriteNode *lokomotywa;


#pragma mark BOOLs
@property (nonatomic) BOOL touchingBear;
@property (nonatomic) CGPoint touchingPoint;
@property (nonatomic) BOOL touchingCarillon;

@end

@implementation GameScene

-(void)didMoveToView:(SKView *)view {
    /* Setup your scene here */
    [self setupLevel1];
    [self addBottomEdge:self.size];
    

    
    
}

-(void)setupLevel1{
    
    self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
    // self.physicsWorld.gravity = CGVectorMake(0, 0);
    // self.physicsWorld.contactDelegate = self;
    [self setupBackground];
    
    [self setupCharacter];
    
    [self setupClockHands];
    
    [self setupLadyBird];
    
   // [self setupPudlo];
    
    [self setupBear];
    
    // [self setupLokomotywa];
    
    //[self setupPilka];
   // [self emitterEffect];
    
    

}
/*
-(void)emitterEffect{
    
    //emitter effects test
    self.player = [SKNode node];
    
    SKShapeNode *circle = [SKShapeNode node];
    circle.path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(-10, -10, 20, 20)].CGPath;
    circle.fillColor = [SKColor blueColor];
    circle.glowWidth = 5;
    circle.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
    
    self.trail = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"Spark" ofType: @"sks"]];
    // self.trail.zPosition = 1;
    self.trail.targetNode = self;
    self.trail.position = CGPointMake(CGRectGetMidX(circle.frame), CGRectGetMidY(circle.frame));
    
    [self.player addChild:self.trail];
    
    self.player.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
    
    [self addChild:self.player];
}
*/

-(void)addBottomEdge:(CGSize)size{
    
    SKNode *bottomEdge = [SKNode node];
    bottomEdge.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, 40) toPoint:CGPointMake(size.width, 40)];
    
    [self addChild:bottomEdge];
    
}

#pragma mark TLO

-(void)setupBackground{
    SKSpriteNode *backgroundImage = [SKSpriteNode spriteNodeWithImageNamed:@"tlo"];
    backgroundImage.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
    backgroundImage.zPosition = -2;
    
    [self addChild:backgroundImage];
    
    SKAction *coloredBackground = [SKAction colorizeWithColor:[SKColor greenColor] colorBlendFactor:0.8 duration:2];

    [backgroundImage runAction:[SKAction repeatAction:coloredBackground count:10]];
   
    
}
#pragma mark POSTAC
-(void)setupCharacter{
    
    self.carillon = [SKSpriteNode spriteNodeWithImageNamed:@"postac lezaca oczy01.png"];
    NSLog(@"width:%i height:%i", (int)self.size.width, (int)self.size.height);
    self.carillon.position = CGPointMake(285, 280);
    NSLog(@"%f & %f", self.carillon.position.x, self.carillon.position.y);
    
    
    
    [self addChild:self.carillon];
    SKAction *coloredBackground     = [SKAction colorizeWithColor:[SKColor whiteColor] colorBlendFactor:0.8 duration:2];
    
    [self.carillon runAction:[SKAction repeatAction:coloredBackground count:10]];
    //[self setupMainCharacterAnimation];
}

-(void)startMainCharacterAnimation{
    NSMutableArray *textures = [NSMutableArray arrayWithCapacity:2];
    
    for (int i = 1; i<3; i++) {
        NSString *textureName = [NSString stringWithFormat:@"postac lezaca oczy0%i.png",i];
        SKTexture *texture = [SKTexture textureWithImageNamed:textureName];
        [textures addObject:texture];
    }
    //creating an action from array of textures
    CGFloat duration = arc4random()%5;
    
    
    
    SKAction *blink = [SKAction animateWithTextures:textures timePerFrame:1];
    SKAction *wait = [SKAction waitForDuration:duration];
    SKAction *move = [SKAction rotateByAngle:-1.57 duration:0.2];
    SKAction *moveDown = [SKAction moveTo:CGPointMake(285, 270) duration:0.5];
    SKAction *mainCharacterAnimation = [SKAction sequence:@[blink,  move, moveDown]];
    SKAction *mainCharacterBlinking = [SKAction sequence:@[blink, wait]];
    
    // [self.carillon runAction:[SKAction repeatActionForever:mainCharacterAnimation]];
    [self.carillon runAction:mainCharacterAnimation];
    [self.carillon runAction:[SKAction repeatActionForever:mainCharacterBlinking]];
    
}

#pragma mark ZEGAR
-(void)setupClockHands{
   
    self.clockHand1 = [SKSpriteNode spriteNodeWithImageNamed:@"wskazowka 1.png"];
    self.clockHand1.position = CGPointMake(285, 590);
    
    [self addChild:self.clockHand1];
    
    self.clockHand2 = [SKSpriteNode spriteNodeWithImageNamed:@"wskazowka 2.png"];
    self.clockHand2.position = CGPointMake(245, 590);
    
    [self addChild:self.clockHand2];
}
#pragma mark BIEDRONKA

-(void)setupLadyBird{
    
    self.biedrona = [SKSpriteNode spriteNodeWithImageNamed:@"biedrona1.png"];
    //   self.biedrona.position = CGPointMake(700, 400);
    self.biedrona.position = CGPointMake(self.size.width - self.biedrona.size.width, self.size.height/2-40);
    [self addChild:self.biedrona];
}

#pragma mark ZABAWKI
#pragma mark MISIO

-(void)setupBear{
    
    self.trail = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"Spark" ofType: @"sks"]];
    // self.trail.zPosition = 1;
   // self.trail.targetNode = self;
    self.trail.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
    
    [self.misiu addChild:self.trail];
    
   // self.player.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
  
    self.misiu = [SKSpriteNode spriteNodeWithImageNamed:@"misiu poziom.png"];
    self.misiu.zPosition = 1;
    self.misiu.position = CGPointMake(700, 60);
    
    
    
    self.misiu.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:self.misiu.size];
    self.misiu.physicsBody.restitution = 0.5;
    
    self.touchingCarillon = YES;
   
    
    
    [self addChild:self.misiu];

    
    
}
#pragma mark PUDLO

-(void)setupPudlo{
    self.pudlo = [SKSpriteNode spriteNodeWithImageNamed:@"pudlo.png"];
    self.pudlo.position = CGPointMake(700, 250);
    self.pudlo.zPosition = -1;
    [self addChild:self.pudlo];
    
}
#pragma mark PILKA

-(void)setupPilka{
    
    self.pilka = [SKSpriteNode spriteNodeWithImageNamed:@"pilka.png"];
    self.pilka.position = CGPointMake(self.size.width - 70, 400);
    self.pilka.zPosition = 1;
    self.pilka.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.pilka.frame.size.width/2];
    
    /*
    //testing
    NSLog(@"%f", self.pilka.frame.size.width/2);
    SKShapeNode *shapeN = [SKShapeNode shapeNodeWithCircleOfRadius:self.pilka.frame.size.width/2];
    shapeN.position = self.pilka.position;
    shapeN.zPosition = -1;

    SKShapeNode *dot = [SKShapeNode shapeNodeWithEllipseOfSize:CGSizeMake(10, 10)];
    dot.fillColor = [SKColor blackColor];
    dot.position = self.pilka.position;
    dot.zPosition = 3;
    [self addChild:dot];
    NSLog(@"%f, %f",self.pilka.anchorPoint.x, self.pilka.anchorPoint.y);

    //testing
    [self addChild:shapeN];
     
     */
    self.pilka.physicsBody.restitution = 0.5;
     self.pilka.physicsBody.affectedByGravity = YES;
    self.pilka.physicsBody.dynamic = NO;
    [self addChild:self.pilka];
    
}
#pragma mark LOKOMOTYWA

-(void)setupLokomotywa{
    self.lokomotywa = [SKSpriteNode spriteNodeWithImageNamed:@"lokomotywa"];
    self.lokomotywa.position = CGPointMake(self.size.width - 60, 60);
    self.lokomotywa.zPosition = 1; //same like the bear
    self.lokomotywa.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:self.lokomotywa.frame.size];
    [self addChild:self.lokomotywa];
}

-(SKColor *)randomColor
{
    switch (arc4random()%5) {
        case 0: return [SKColor redColor];
        case 1: return [SKColor blueColor];
        case 2: return [SKColor greenColor];
        case 3: return [SKColor purpleColor];
        case 4: return [SKColor yellowColor];

    }
    return [SKColor blueColor];
}


#pragma mark TOUCH


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
   // [self touchesMoved:touches withEvent:event];
    
    
    
    
    for (UITouch *touch in touches){
        
        CGPoint location = [touch locationInNode:self];
        CGPoint newLocation = CGPointMake(location.x, 160);
        if (self.touchingCarillon) {
            
            
            if ([self.carillon containsPoint:location]) {
                NSLog(@"just touched the carillon");
                [self startMainCharacterAnimation];
                NSLog(@"started animating");
                self.touchingCarillon = NO;
                           }
        }
        if([self.misiu containsPoint:location]){
            self.touchingBear = YES;
            self.touchingPoint = location;
            
            //self.misiu.position = newLocation;
            self.misiu.physicsBody.velocity = CGVectorMake(0, 0);
            self.misiu.physicsBody.angularVelocity = 0;
            
            self.misiu.physicsBody.affectedByGravity = NO;
            SKAction *rotate = [SKAction rotateByAngle:M_PI_2   duration:0.5];
            
            [self.misiu runAction:rotate];
            
        }else if([self.biedrona containsPoint:location]){
            /*
            NSLog(@"just got here");
            [self.biedrona removeFromParent];
            
            NSString *name = nil;
            
            
            int number = (arc4random()% 3) +1;
            
            
            name = [NSString stringWithFormat:@"biedrona%i.png", number];
            self.biedrona = [SKSpriteNode spriteNodeWithImageNamed:name];
            NSLog(@"%i", number);
            
            self.biedrona.position = CGPointMake(self.size.width - self.biedrona.size.width, self.size.height/2-40);
            [self addChild:self.biedrona];
             
             */
            
            SKAction *colorLadyBird = [SKAction colorizeWithColor:[self randomColor] colorBlendFactor:0.5 duration:0.2];
           // SKAction *walkingLadyBirdLeft = [SKAction moveToX:600 duration:3];
           // SKAction *walkLadyBirdRight = [SKAction moveToX:700 duration:3];
           // SKAction *rotatingLadyBird = [SKAction rotateByAngle:M_PI duration:0.5];
           // SKAction *rotateBack = [SKAction rotateByAngle:M_PI duration:0.5];
            [self.biedrona runAction:colorLadyBird];
            
            
            //put this into completion block!
           // [self.biedrona runAction:[SKAction sequence:@[rotatingLadyBird, walkLadyBirdRight, rotateBack]]];
        
        
        if ([self.pilka containsPoint:location]) {
            self.pilka.physicsBody.velocity = CGVectorMake(0, 0);
            self.pilka.physicsBody.angularVelocity = 0;
            // self.pilka.physicsBody.affectedByGravity = YES;
            self.pilka.position = newLocation;
        }
            
    }
    }
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    self.touchingPoint = [[touches anyObject] locationInNode:self];
    
   // [self.player runAction:[SKAction moveTo:[[touches anyObject] locationInNode:self] duration:0.01]];
    
    
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    self.touchingBear = NO;
    self.misiu.physicsBody.affectedByGravity = YES;
    
}
-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    
    self.touchingBear = NO;
    self.misiu.physicsBody.affectedByGravity = YES;
}

-(void)update:(CFTimeInterval)currentTime {
    
    
    if (self.touchingBear) {
        
        self.misiu.position = self.touchingPoint;
    }
    
}

@end

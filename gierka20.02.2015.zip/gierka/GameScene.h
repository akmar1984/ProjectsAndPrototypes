//
//  GameScene.h
//  gierka
//

//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene <SKPhysicsContactDelegate>

@end

//
//  BellBody.h
//  gierka
//
//  Created by Marek Tomaszewski on 06/02/2015.
//  Copyright (c) 2015 CS193p. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface BellBody : SKSpriteNode{
    CGPoint _velocity;
}
@property (nonatomic)SKSpriteNode *bellsHead;
@property (nonatomic)SKSpriteNode *bellsBody;
-(instancetype)initBellWithBodyandHeadInPosition:(CGPoint)position;
-(void)moveHeadTowards:(CGPoint)location;
@end

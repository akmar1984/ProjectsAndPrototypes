//
//  GameScene2.h
//  gierka
//
//  Created by Marek Tomaszewski on 20/11/2014.
//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene2 : SKScene

@end

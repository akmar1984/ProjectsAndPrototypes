//
//  BellBody.m
//  gierka
//
//  Created by Marek Tomaszewski on 06/02/2015.
//  Copyright (c) 2015 CS193p. All rights reserved.
//

#import "BellBody.h"
#import "SKTUtils.h"
static const float MOVE_POINTS_PER_SEC = 60.0;

@implementation BellBody
-(instancetype)initBellWithBodyandHeadInPosition:(CGPoint)position{
    
    if (self = [super init]) {
        
        self.bellsBody = [SKSpriteNode spriteNodeWithImageNamed:@"BellBody"];
        self.bellsBody.position = position;
        self.bellsBody.name = @"charactersBody";
        [self addChild:self.bellsBody];
        self.bellsHead = [SKSpriteNode spriteNodeWithImageNamed:@"BellsHead"];
      
        [self.bellsBody addChild:self.bellsHead];
          self.bellsHead.position = CGPointMake(-5, 145);
        
        self.bellsBody.zPosition = 100;
        self.bellsHead.zPosition = 101;
    }
    
    return self;
}
-(void)moveHeadTowards:(CGPoint)location
{
    CGPoint offset = CGPointSubtract(location, self.bellsHead.position);
    CGFloat length = sqrtf(offset.x * offset.x + offset.y * offset.y);
    
    CGPoint direction = CGPointMake(offset.x /length, offset.y / length);
    _velocity = CGPointMake(direction.x * MOVE_POINTS_PER_SEC, direction.y *MOVE_POINTS_PER_SEC);
    
   
       SKConstraint *angleConstraint = [SKConstraint zRotation:[SKRange rangeWithLowerLimit:-M_PI /8  upperLimit:M_PI /8]];
    self.bellsHead.constraints = @[angleConstraint];
     self.bellsHead.zRotation = CGPointToAngle(_velocity);
    SKAction *rotate = [SKAction rotateToAngle:self.bellsHead.zRotation duration:2];
    if (self.bellsHead) {
        [self.bellsHead runAction:rotate];

    }

}
@end

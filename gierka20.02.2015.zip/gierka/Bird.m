//
//  Bird.m
//  gierka
//
//  Created by Marek Tomaszewski on 03/02/2015.
//  Copyright (c) 2015 CS193p. All rights reserved.
//

#import "Bird.h"

@implementation Bird

-(instancetype)initBirdWithPosition:(CGPoint)position{
    
    if (self = [super init]){
        
        self.bird = [SKSpriteNode spriteNodeWithImageNamed:@"bird1"];
        self.bird.position = position;
        
        
    }
    
    return self;
}
@end

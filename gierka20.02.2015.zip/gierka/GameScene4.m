//
//  GameScene4.m
//  gierka
//
//  Created by Marek Tomaszewski on 11/12/2014.
//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import "GameScene4.h"
#import "Flowers.h"
#import "Bird.h"


@import AVFoundation;
@interface GameScene4 ()

@property (nonatomic)SKSpriteNode *character;
@property (nonatomic)SKSpriteNode *background;
@property (nonatomic)SKSpriteNode *cow;
@property (nonatomic)SKSpriteNode *cowsHead;
@property (nonatomic)SKSpriteNode *cowTail;

@property (nonatomic)SKSpriteNode *squirrel;
@property (nonatomic)SKSpriteNode *squirrelHead;
@property (nonatomic)SKSpriteNode *squirrelTail;
@property (nonatomic)SKSpriteNode *nuts;
@property (nonatomic)SKSpriteNode *nuts2;
@property (nonatomic)SKSpriteNode *nuts3;
@property (nonatomic) BOOL touchingNuts;
@property (nonatomic) BOOL touchingNuts2;
@property (nonatomic) BOOL touchingNuts3;
@property (nonatomic) CGPoint touchingPoint;
@property (nonatomic) CGPoint originalPosition;

@property (nonatomic)SKSpriteNode *bird;
@property (nonatomic)NSArray *cowWalkingFrames;
@property (nonatomic)NSArray *squirrelWalkingFrames;

@property (nonatomic)SKSpriteNode *fence;
@property (nonatomic)SKSpriteNode *tree;
@property (nonatomic)SKSpriteNode *cloud1;
@property (nonatomic)SKSpriteNode *cloud2;
@property (nonatomic)SKSpriteNode *cloud3;
@property (nonatomic)SKSpriteNode *cloud4;
@property (nonatomic)SKSpriteNode *cloud5;
@property (nonatomic)SKSpriteNode *cloud6;
@property SKSpriteNode *flower;
@property SKSpriteNode *flower2;


//@property Flowers *flowerTwo;
//@property Flowers *flowerThree;




@property SKShapeNode *footer;
@property (nonatomic) NSArray *characterWalkingFrames;
@property (nonatomic)SKEmitterNode *chimneyFlame;
@property (nonatomic)SKEmitterNode *chimneyFlame2;
@property (nonatomic)SKEmitterNode *chimneyFlame3;
@property (nonatomic)SKEmitterNode *littleSparkEmitter;
@property (nonatomic)SKEmitterNode *bigSparkEmitter;

@property (nonatomic)AVAudioPlayer *backgroundMusicPlayer;
@property (nonatomic)AVAudioPlayer *backgroundMusicPlayer2;
@property SKSpriteNode *soundIcon;
@property SKSpriteNode *arrow;

@property (nonatomic)SKAction *cloudMoving;
@property (nonatomic)SKAction *fadeOut;
@property (nonatomic)SKAction *fadeIn;
@property (nonatomic)SKAction *playWind;


@property (nonatomic) BOOL touchingCow;
@property (nonatomic) BOOL touchingSquirrel;

@property (nonatomic) BOOL musicOn;
@property BOOL flowerOpenFlag;



@property (nonatomic) CGPoint cloudPoint;



@end
static const int BODY_OFFSET = 50;

@implementation GameScene4
{
    Flowers *_flowerOne;
    Bird *_bird;
    SKNode *_flowerNode;
    SKNode * _birdNode;
    
    
}
 


-(void)didMoveToView:(SKView *)view{
    
    [self setupLevel4];
  //  self.playWind = [SKAction playSoundFileNamed:@"Wiatr SFX.mp3" waitForCompletion:NO];
    [self playBackgroundMusic2:@"Wiatr SFX.mp3"];
    
    [self.backgroundMusicPlayer2 play];
  //  [self runAction:self.playWind];
}



-(void)setupLevel4{
    [self setupBackground4];
    [self setupCow];
    [self setupSquirrel];
    [self setupFence];
    [self setupTree];
    [self setupBird];
    [self setupCloud];
    [self setupCharacter];
    [self setupFooter];
    
    [self setupSoundIcon];
}
-(void)setupFooter{
    
    self.footer = [SKShapeNode shapeNodeWithRectOfSize:CGSizeMake(1024, 70)];
    
    self.footer.fillColor = [SKColor whiteColor];
    self.footer.zPosition = 101;
    self.footer.position = CGPointMake(512, 50);
    //  self.footer.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, 120) toPoint:CGPointMake(size.width, 120)];
    
    [self addChild:self.footer];
    
    
}
-(void)setupSoundIcon{
    self.soundIcon = [SKSpriteNode spriteNodeWithImageNamed:@"glosnik"];
    self.soundIcon.position = CGPointMake(self.soundIcon.size.width, self.size.height-self.soundIcon.size.height);
    [self addChild:self.soundIcon];
    
}
-(void)setupArrow{
    self.arrow = [SKSpriteNode spriteNodeWithImageNamed:@"arrowRight"];
    self.arrow.position = CGPointMake(self.size.width-self.arrow.size.width/2, self.arrow.size.height);
    [self addChild:self.arrow];
    
}
-(void)setupBackground4{
    self.background = [SKSpriteNode spriteNodeWithImageNamed:@"background4"];
    self.background.anchorPoint = CGPointZero;
    self.background.zPosition = -2;
    [self addChild:self.background];
    
    [self playBackgroundMusic:@"Bell Music Field Scene3.mp3"];
    self.musicOn = YES;
   [self.backgroundMusicPlayer play];
    
    [self setupChimneyEmitterEffect];
    [self setupFlower];
    
}

-(void)setupFlower{
    
    _flowerNode = [SKNode node];
    _flowerOne = [[Flowers alloc] initWithPosition:CGPointMake(300, 300)];
    [_flowerNode addChild:_flowerOne];
    [self addChild:_flowerNode];
    
}
- (void)showSoundButtonForTogglePosition:(BOOL)togglePosition
{
    if (togglePosition)
    {
        self.soundIcon.texture = [SKTexture textureWithImageNamed:@"glosnik2"];
        self.musicOn = NO;
        [_backgroundMusicPlayer stop];
    }
    else
    {
        self.soundIcon.texture = [SKTexture textureWithImageNamed:@"glosnik"];
        self.musicOn = YES;
        [_backgroundMusicPlayer play];
    }
}

- (void)playBackgroundMusic:(NSString *)filename
{
    
    NSError *error;
    NSURL *backgroundMusicURL = [[NSBundle mainBundle] URLForResource:filename withExtension:nil];
    self.backgroundMusicPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:backgroundMusicURL error:&error];
    self.backgroundMusicPlayer.numberOfLoops = -1;
    self.backgroundMusicPlayer.volume = 0.4;
    [self.backgroundMusicPlayer prepareToPlay];
}
- (void)playBackgroundMusic2:(NSString *)filename
{
    
    NSError *error;
    NSURL *backgroundMusicURL = [[NSBundle mainBundle] URLForResource:filename withExtension:nil];
    self.backgroundMusicPlayer2 = [[AVAudioPlayer alloc] initWithContentsOfURL:backgroundMusicURL error:&error];
    self.backgroundMusicPlayer2.numberOfLoops = -1;
    self.backgroundMusicPlayer2.volume = 0.05;
    [self.backgroundMusicPlayer2 prepareToPlay];
}
-(void)setupSquirrel{
    self.touchingSquirrel = NO;
    NSMutableArray *walkFrames = [NSMutableArray array];
    [walkFrames addObject:[SKTexture textureWithImageNamed:@"wiewiora1"]];
    [walkFrames addObject:[SKTexture textureWithImageNamed:@"wiewiora2"]];
    
    self.squirrelWalkingFrames = walkFrames;
    SKTexture *temp = self.squirrelWalkingFrames[0];
    self.squirrel = [SKSpriteNode spriteNodeWithTexture:temp];
    self.squirrel.position = CGPointMake(self.size.width - self.squirrel.size.width, 180);
    [self addChild:self.squirrel];
    
    self.squirrelHead = [SKSpriteNode spriteNodeWithImageNamed:@"wiewiora glowa"];
    self.squirrelHead.position = CGPointMake(-50,30);
    self.squirrelHead.zPosition = 2;
    
    [self.squirrel addChild:self.squirrelHead];
    [self setupSquirrelHeadAnimation];
    
    self.nuts = [SKSpriteNode spriteNodeWithImageNamed:@"orzech"];
    self.nuts.position = CGPointMake(self.nuts.size.width, 300);
    self.nuts.zPosition = 2;
    [self addChild:self.nuts];
    
    self.nuts2 = [SKSpriteNode spriteNodeWithImageNamed:@"orzech"];
    self.nuts2.position = CGPointMake(self.size.width - self.nuts2.size.width, 500);
    self.nuts2.zPosition = 2;
    self.nuts2.zRotation = M_PI_4;
    [self addChild:self.nuts2];
    
    self.nuts3 = [SKSpriteNode spriteNodeWithImageNamed:@"orzech"];
    self.nuts3.position = CGPointMake(650, 500);
    self.nuts3.zPosition = 2;
    self.nuts3.zRotation = M_PI_2 *3;
    [self addChild:self.nuts3];
    
}
-(void)setupSquirrelHeadAnimation{
    
    SKAction *wiggleHeadUp = [SKAction rotateByAngle:M_PI_4/16 duration:0.7];
    SKAction *wiggleHeadDown = [SKAction rotateByAngle:-M_PI_4/16 duration:0.7];
    SKAction *wigglingHead = [SKAction repeatAction:[SKAction sequence:@[wiggleHeadDown, wiggleHeadUp]] count:13];
    SKAction *wait = [SKAction waitForDuration:2];
    SKAction *seq =  [SKAction sequence:@[wigglingHead, wait]];
    [self.squirrel runAction:[SKAction repeatActionForever:seq]];
    
    
}
-(BOOL)isWithinTheSquirrel:(CGPoint)currentLocation{
    if (currentLocation.x >= self.squirrel.position.x - BODY_OFFSET-50 && currentLocation.x <= self.squirrel.position.x + BODY_OFFSET+50 && currentLocation.y >= self.squirrel.position.y - BODY_OFFSET-50 && currentLocation.y <= self.squirrel.position.y + BODY_OFFSET +50){
        
        return YES;
    }else{
        return NO;
    }

    
}
-(void)setupCow{
    self.touchingCow = NO;
    NSMutableArray *walkFrames = [NSMutableArray array];
    [walkFrames addObject:[SKTexture textureWithImageNamed:@"krowa1"]];
    [walkFrames addObject:[SKTexture textureWithImageNamed:@"krowa22"]];
    
    self.cowWalkingFrames = walkFrames;
    SKTexture *temp = self.cowWalkingFrames[0];
    self.cow = [SKSpriteNode spriteNodeWithTexture:temp];
    
    
    
    self.cow.position = CGPointMake(self.cow.size.width, CGRectGetMidX(self.frame));
    [self addChild:self.cow];
    
    self.cowsHead = [SKSpriteNode spriteNodeWithImageNamed:@"krowaGlowaDuza"];
    self.cowsHead.anchorPoint = CGPointMake(1, 1);
    self.cowsHead.position = CGPointMake(-30, 90);
    self.cowsHead.zPosition = 2;
    
    self.cowTail = [SKSpriteNode spriteNodeWithImageNamed:@"cowTail"];
    self.cowTail.anchorPoint = CGPointMake(0, 1);
    self.cowTail.position = CGPointMake(120, 80);
    
    [self.cow addChild:self.cowTail];
    [self.cow addChild:self.cowsHead];
    
   // [self setupCowsHeadAnimation];
    
}
-(void)moveCow{
   // CGFloat randomX = arc4random()%200+600;
    
    SKAction *moveLeft = [SKAction moveToX:276 duration:7]; //x = 600 worked
    SKAction *animate = [SKAction animateWithTextures:self.cowWalkingFrames timePerFrame:0.3f];
    SKAction *moveLeftWithAnimation = [SKAction group:@[moveLeft, [SKAction repeatAction:animate count:12]]];
    SKAction *moveRight = [SKAction moveToX:884 duration:7];
    SKAction *moveRightWithAnimation = [SKAction group:@[moveRight, [SKAction repeatAction:animate count:12]]];
    SKAction *wait = [SKAction waitForDuration:1];
    SKAction *wiggleTailUp = [SKAction rotateByAngle:M_PI_4/4 duration:0.5];
    SKAction *wiggleTailDown = [SKAction rotateByAngle:-M_PI_4/4 duration:0.5];
    SKAction *wiggling = [SKAction repeatAction:[SKAction sequence:@[wiggleTailUp, wiggleTailDown]] count:17];
    SKAction *wiggleHeadUp = [SKAction rotateByAngle:M_PI_4/16 duration:0.7];
    SKAction *wiggleHeadDown = [SKAction rotateByAngle:-M_PI_4/16 duration:0.7];
    SKAction *wigglingHead = [SKAction repeatAction:[SKAction sequence:@[wiggleHeadDown, wiggleHeadUp]] count:13];
    SKAction *turnRight = [SKAction runBlock:^{
        self.cow.xScale = fabs(self.cow.xScale) *-1;
        
    }];
    SKAction *turnLeft = [SKAction runBlock:^{
        self.cow.xScale = fabs(self.cow.xScale) *1;
        
        
    }];
    [self.cowsHead runAction:wigglingHead];
    [self.cowTail runAction:wiggling];
    [self.cow runAction:[SKAction sequence:@[turnRight, moveRightWithAnimation, wait, turnLeft, wait, moveLeftWithAnimation, wait]]completion:^{
        
        self.touchingCow = NO;
    }];
}
-(void)setupFence{
    
    self.fence = [SKSpriteNode spriteNodeWithImageNamed:@"plotek2"];
    self.fence.position = CGPointMake(self.size.width-self.fence.size.width/2, 380);
    
    [self addChild:self.fence];
    
}
-(void)setupCowsHeadAnimation{
    self.touchingCow = YES;
    SKAction *rotate = [SKAction rotateByAngle:M_PI_4/4 duration:0.2];
    SKAction *reverseRotation = [rotate reversedAction];
    SKAction *wait = [SKAction waitForDuration:2];
    SKAction *cowMovementSequence = [SKAction sequence:@[rotate, wait, reverseRotation, wait]];
    
    
    SKTexture *cowsLookup = [SKTexture textureWithImageNamed:@"cow02"];
    SKAction *changeTexture = [SKAction setTexture:cowsLookup];
    SKAction *cowsHeadUp = [SKAction moveToY:120 duration:0.1];
    SKAction *wavingTail = [SKAction rotateByAngle:M_PI_4/4 duration:0.5];
    SKAction *wavingTailReversed = [wavingTail reversedAction];
    SKAction *wavingTailSequence = [SKAction sequence:@[wavingTail, wavingTailReversed, wait]];
    
    //SKAction *block = [SKAction runBlock:^{
    
    [self.cowTail runAction:[SKAction repeatActionForever:wavingTailSequence]];
    SKAction *rotateHeadUp = [SKAction rotateByAngle:-M_PI_4/4 duration:0.5];
    SKAction *rotateBack = [rotateHeadUp reversedAction];
    
    
    [self.cowsHead runAction:cowMovementSequence completion:^{
       SKAction *seqCow = [SKAction sequence:@[cowsHeadUp, wait, rotateHeadUp, rotateBack]];
        [self.cow runAction:changeTexture];
        //[self.cowsHead runAction:cowsHeadUp];
        [self.cowsHead runAction:seqCow  completion:^{
           
            
            [self.cowsHead runAction:[SKAction sequence:@[rotateHeadUp, rotateBack, wait]]];
            
            
            //cows coming down
            SKTexture *cowsLookdown = [SKTexture textureWithImageNamed:@"cow01"];
            SKAction *changeTexture3 = [SKAction setTexture:cowsLookdown];
            SKAction *cowsHeadDown = [SKAction moveToY:60 duration:0.1];
            
            [self.cow runAction:changeTexture3];
            [self.cowsHead runAction:cowsHeadDown];
            self.touchingCow = NO;
        }];
        
    }];
    //  [self.cow runAction:[SKAction repeatActionForever:block]];
    
}

-(void)setupBird{
    _birdNode = [SKNode node];
   _bird = [[Bird alloc] initBirdWithPosition:CGPointMake(self.size.width - self.bird.size.width, 440)];
    [_birdNode addChild:_bird];
    _birdNode.zPosition = 200;
    [self addChild:_birdNode];
    [self setupBirdAnimation];
    
}

-(void)setupTree{
    
    self.tree = [SKSpriteNode spriteNodeWithImageNamed:@"drzewoZielone"];
    self.tree.position = CGPointMake(self.size.width-100, self.tree.size.height/2);
    self.tree.zPosition = 100;
    [self addChild:self.tree];
    
}
-(void)setupCloud{
    
    self.cloud1 = [SKSpriteNode spriteNodeWithImageNamed:@"smallCloud"];
    self.cloud1.position = CGPointMake(900, 764);
    [self addChild:self.cloud1];
    
    self.cloud2 = [SKSpriteNode spriteNodeWithImageNamed:@"smallCloud"];
    self.cloud2.position = CGPointMake(100, self.size.height-self.cloud2.size.height/2);
    [self addChild:self.cloud2];

    
    self.cloud3 = [SKSpriteNode spriteNodeWithImageNamed:@"cloud"];
    self.cloud3.position = CGPointMake(400, 700);
    [self addChild:self.cloud3];

    
    self.cloud4 = [SKSpriteNode spriteNodeWithImageNamed:@"cloud"];
    self.cloud4.position = CGPointMake(600, self.size.height-self.cloud1.size.height/2);
    [self addChild:self.cloud4];
    
    self.cloud5 = [SKSpriteNode spriteNodeWithImageNamed:@"cloud"];
    self.cloud5.position = CGPointMake(1124, 764);
    [self addChild:self.cloud5];
    
    self.cloud6 = [SKSpriteNode spriteNodeWithImageNamed:@"cloud"];
    self.cloud6.position = CGPointMake(900, 720);
    [self addChild:self.cloud6];
    
    
    self.cloudMoving = [SKAction moveToX:-self.cloud1.size.width duration:30];
    self.cloudMoving.timingFunction = SKActionTimingLinear;
    [self.cloud1 runAction:self.cloudMoving completion:^{
        
        [self.cloud1 removeFromParent];
        self.cloud1.position  = CGPointMake(1124, 764);
        [self addChild:self.cloud1];
        
        
    }];
    
     
    
   // SKAction *cloudMoving2 = [SKAction moveToX:-self.size.width/2 duration:30];
    [self.cloud2 runAction:self.cloudMoving completion:^{
        
        [self.cloud2 removeFromParent];
        self.cloud2.position  = CGPointMake(1324, self.size.height-self.cloud2.size.height/2);
        [self addChild:self.cloud2];
        
        
    }];

    [self.cloud3 runAction:self.cloudMoving completion:^{
        
        [self.cloud3 removeFromParent];
        self.cloud3.position  = CGPointMake(1224, 700);
        [self addChild:self.cloud3];
        
        
    }];
    [self.cloud4 runAction:self.cloudMoving completion:^{
        
        [self.cloud4 removeFromParent];
        self.cloud4.position  = CGPointMake(1424, 680);
        [self addChild:self.cloud4];
        
        
    }];
    
    [self.cloud5 runAction:self.cloudMoving completion:^{
        
        //[self.cloud5 removeFromParent];
        self.cloud5.position  = CGPointMake(1424, 704);
       // [self addChild:self.cloud5];
        
        
    }];
    
    [self.cloud6 runAction:self.cloudMoving completion:^{
        
        
        self.cloud6.position  = CGPointMake(1424, 720);
        
        
        
    }];

    
}
-(void)setupCharacter{

    NSMutableArray *walkFrames = [NSMutableArray array];
    
    SKTextureAtlas *characterAnimatedAtlas = [SKTextureAtlas atlasNamed:@"carillon"];
    NSInteger numImages = characterAnimatedAtlas.textureNames.count;
    
    for (int i = 1; i<=numImages/2; i++) {
        NSString *textureName = [NSString stringWithFormat:@"carillon0%i.png",i];
        SKTexture *temp = [characterAnimatedAtlas textureNamed:textureName];
        [walkFrames addObject:temp];
    }
    
    self.characterWalkingFrames = walkFrames;
    
    SKTexture *temp = self.characterWalkingFrames[0];
    self.character = [SKSpriteNode spriteNodeWithTexture:temp];
    self.character.position = CGPointMake(600, 260);
    [self addChild:self.character];

}

-(void)setupCharacterAnimation{
    
    
    
   // [self.character runAction:[SKAction animateWithTextures:walkFrames timePerFrame:0.1f] withKey:@"walkingInPlaceCharacter"];
    [self.character runAction:[SKAction repeatActionForever:
                               [SKAction animateWithTextures:self.characterWalkingFrames
                                       timePerFrame:0.1f
                                             resize:NO
                                            restore:YES]] withKey:@"walkingInPlaceCarillon"];
   
}
-(void)setupBirdAnimation{
    
    
    NSMutableArray *textures = [NSMutableArray arrayWithCapacity:2];
    // NSMutableArray *texturesStanding = [NSMutableArray arrayWithCapacity:3];
    
    for (int i = 1; i<3; i++) {
        NSString *textureName = [NSString stringWithFormat:@"bird%i.png",i];
        SKTexture *texture = [SKTexture textureWithImageNamed:textureName];
        [textures addObject:texture];
    }
    
    
    SKAction *birdMoves = [SKAction animateWithTextures:textures timePerFrame:1];
    SKAction *wait = [SKAction waitForDuration:2];
    SKAction *cowMovingSequence = [SKAction sequence:@[birdMoves,wait]];
    
    [self.bird runAction:[SKAction repeatActionForever:cowMovingSequence]];
    
}
-(void)setupChimneyEmitterEffect{
    
    self.chimneyFlame = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"chimneyFlame" ofType: @"sks"]];
    self.chimneyFlame.position = CGPointMake(190,670);
    [self addChild:self.chimneyFlame];
    
    self.chimneyFlame2 = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"chimneyFlame" ofType: @"sks"]];
    self.chimneyFlame2.position = CGPointMake(335,640);
    [self addChild:self.chimneyFlame2];
    
    self.chimneyFlame3 = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"chimneyFlame" ofType: @"sks"]];
    self.chimneyFlame3.position = CGPointMake(820,670);
    [self addChild:self.chimneyFlame3];
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    for (UITouch *touch in touches)
    {
        CGPoint location = [touch locationInNode:self];
        
        self.littleSparkEmitter = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"LittleSpark" ofType:@"sks"]];
        self.littleSparkEmitter.zPosition = 100;
        self.littleSparkEmitter.position = location;
        
        [self addChild:self.littleSparkEmitter];
        
        if   ([self.soundIcon containsPoint:location]){
            
            [self showSoundButtonForTogglePosition:self.musicOn];
        }
        if ([_flowerOne.flowerOne containsPoint:location]) {
            
            [_flowerOne loadTexturesWithActionForFlower];
            
        }
        if ([_flowerOne.flowerTwo containsPoint:location]) {
           
                [_flowerOne loadTexturesWithActionForFlowerTwo];
          
        }
        if ([_flowerOne.flowerThree containsPoint:location]) {
            
            [_flowerOne loadTexturesWithActionForFlowerThree];
            
        }
        if ([self.nuts containsPoint:location]) {
            self.originalPosition = self.nuts.position;
            self.touchingNuts = YES;
            self.nuts.zPosition = 400;
            self.nuts.xScale = 1.4;
            self.nuts.yScale = 1.4;
            self.touchingPoint = location;
        }
        
        if ([self.nuts2 containsPoint:location]) {
            self.originalPosition = self.nuts2.position;
            self.touchingNuts2 = YES;
            self.nuts2.zPosition = 400;
            self.nuts2.xScale = 1.4;
            self.nuts2.yScale = 1.4;
            self.touchingPoint = location;
        }
        if ([self.nuts3 containsPoint:location]) {
            self.originalPosition = self.nuts3.position;
            self.touchingNuts3 = YES;
            self.nuts3.zPosition = 400;
            self.nuts3.xScale = 1.4;
            self.nuts3.yScale = 1.4;
            self.touchingPoint = location;
        }
        
//        if ([self.flower containsPoint:location]&& self.flowerOpenFlag== NO){
//        
//            [self.flower setTexture:[SKTexture textureWithImageNamed:@"flowerOpen"]];
//            
//            self.flowerOpenFlag = YES;
//
//        }else {
//            [self.flower setTexture:[SKTexture textureWithImageNamed:@"flower1"]];
//            
//        }
        if([self.cow containsPoint:location] && !self.touchingCow)
        {
            [self.cow runAction:[SKAction playSoundFileNamed:@"Krowa SFX.mp3" waitForCompletion:NO]];
            self.touchingCow = YES;
            [self moveCow];
        }
        
        if ([self.bird containsPoint:location]) {
           [self.bird runAction:[SKAction playSoundFileNamed:@"birdSinging.mp3" waitForCompletion:NO]];

        }
        
        
        
        

    }
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    CGPoint currentPoint = [[touches anyObject]locationInNode:self];

    if (self.touchingNuts) {

        if ([self isWithinTheSquirrel:currentPoint]) {
            self.touchingNuts = NO;
            [self.nuts removeFromParent];
            [self setupBigSparkEmiter:currentPoint];
            [self animateTheSquirrelHappiness];
        }else{
            [self animatePuttingThingsBack:self.nuts];
        self.touchingNuts = NO;
        }

    }
    if (self.touchingNuts2) {
        
        if ([self isWithinTheSquirrel:currentPoint]) {
            self.touchingNuts2 = NO;
            [self.nuts2 removeFromParent];
            [self setupBigSparkEmiter:currentPoint];
            [self animateTheSquirrelHappiness];
        }else{
            [self animatePuttingThingsBack:self.nuts2];
            self.touchingNuts2 = NO;
        }
        
    }
    if (self.touchingNuts3) {
        
        if ([self isWithinTheSquirrel:currentPoint]) {
            self.touchingNuts3 = NO;
            [self.nuts3 removeFromParent];
            [self setupBigSparkEmiter:currentPoint];
            [self animateTheSquirrelHappiness];
        }else{
            [self animatePuttingThingsBack:self.nuts3];
            self.touchingNuts3 = NO;
        }
        
    }


    //[self walkingCarillon:location];
    
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
   
    self.touchingPoint = [[touches anyObject] locationInNode:self];

}
-(void)animateTheSquirrelHappiness{
    SKAction *rotateBack = [SKAction rotateByAngle:M_PI *2 duration:2];
    SKAction *moveUp = [SKAction moveByX:0 y:100 duration:2];
    SKAction *moveDown = [SKAction moveByX:0 y:-100 duration:2];
    SKAction *groupMove = [SKAction group:@[rotateBack, moveUp, moveDown]];
    
    [self.squirrel runAction:groupMove];
}
-(void)animatePuttingThingsBack:(SKSpriteNode *)node
{
//    if ([self isItFood:node]) {
//        SKAction *scaleDown = [SKAction scaleTo:1.0 duration:0.5];
//        SKAction *moveLeft = [SKAction moveByX:-10 y:0 duration:0.2];
//        SKAction *moveRight = [SKAction moveByX:10 y:0 duration:0.2];
//        
//        SKAction *fastMovementSeq = [SKAction repeatAction:[SKAction sequence:@[moveLeft, moveRight]] count:4];
//        SKAction *moveBack = [SKAction moveTo:self.originalPosition duration: 1];
//        SKAction *rotateBack = [SKAction rotateByAngle:M_PI *2 duration:0.5];
//        SKAction *group = [SKAction group:@[moveBack, rotateBack]];
//        ;
//        
//        SKAction *seq =[SKAction sequence: @[scaleDown, fastMovementSeq, group]];
//        [node runAction:seq];
//    }else
    
        SKAction *scaleDown = [SKAction scaleTo:1.0 duration:0.5];
        SKAction *moveLeft = [SKAction moveByX:-10 y:0 duration:0.2];
        SKAction *moveRight = [SKAction moveByX:10 y:0 duration:0.2];
        
        SKAction *fastMovementSeq = [SKAction repeatAction:[SKAction sequence:@[moveLeft, moveRight]] count:4];
        SKAction *moveBack = [SKAction moveTo:self.originalPosition duration: 1];
        SKAction *rotateBack = [SKAction rotateByAngle:M_PI *2 duration:0.5];
        SKAction *group = [SKAction group:@[moveBack, rotateBack]];
        ;
        
        SKAction *seq =[SKAction sequence: @[scaleDown, fastMovementSeq, group]];
        [node runAction:seq];
    
}

-(void)setupBigSparkEmiter:(CGPoint)coordinates{
    
    
    self.bigSparkEmitter = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"BigSpark" ofType:@"sks"]];
    self.bigSparkEmitter.zPosition = 500;
    self.bigSparkEmitter.position = coordinates;
    
    [self addChild:self.bigSparkEmitter];
}
-(void)characterMoveEnded{
    
    [self.character removeAllActions];
}

-(void)walkingCarillon:(CGPoint)location{
    CGFloat multiplierForDirection;
    
    CGSize screenSize = self.frame.size;

    float bearVelocity = screenSize.width / 3.0;
    
    //x and y distances for move
    // CGPoint moveDifference = CGPointMake(location.x - self.character.position.x, location.y - self.character.position.y);
    CGPoint moveDifference = CGPointMake(location.x - self.character.position.x, location.y - self.character.position.y);
    float distanceToMove = sqrtf(moveDifference.x * moveDifference.x + moveDifference.y * moveDifference.y);
    
    float moveDuration = distanceToMove / bearVelocity;
    
    if (moveDifference.x < 0) {
        multiplierForDirection = 1;
    } else {
        multiplierForDirection = -1;
    }
    self.character.xScale = fabs(self.character.xScale) * multiplierForDirection;
    
    if ([self.character actionForKey:@"bearMoving"]) {
        //stop just the moving to a new location, but leave the walking legs movement running
        [self.character removeActionForKey:@"bearMoving"];
    }
    
    if (![self.character actionForKey:@"walkingInPlaceBear"]) {
        //if legs are not moving go ahead and start them
        [self setupCharacterAnimation];  //start the bear walking
    }
    SKAction *moveAction = [SKAction moveToX:location.x duration:moveDuration];
    //    SKAction *moveAction = [SKAction moveTo:location duration:moveDuration];
    SKAction *doneAction = [SKAction runBlock:(dispatch_block_t)^() {
        [self characterMoveEnded];
    }];
    
    SKAction *moveActionWithDone = [SKAction sequence:@[moveAction,doneAction ]];
    
    [self.character runAction:moveActionWithDone withKey:@"bearMoving"];
    
}



-(void)checkClouds{

    
    if (self.cloud1.position.x == 1124){
        
        
        [self.cloud1 runAction:self.cloudMoving completion:^{
            
            [self.cloud1 removeFromParent];
            self.cloud1.position  = CGPointMake(1124, 764);
            [self addChild:self.cloud1];
        }];
    }
    
    if (self.cloud2.position.x == 1324){
        
        
        [self.cloud2 runAction:self.cloudMoving completion:^{
            
            [self.cloud2 removeFromParent];
            self.cloud2.position  = CGPointMake(1324, self.size.height-self.cloud2.size.height/2);
            [self addChild:self.cloud2];
        }];
    }
    if (self.cloud3.position.x == 1224){
        
        
        [self.cloud3 runAction:self.cloudMoving completion:^{
            
            [self.cloud3 removeFromParent];
            self.cloud3.position  = CGPointMake(1224, 700);
            [self addChild:self.cloud3];
        }];
    }
    if (self.cloud4.position.x == 1424){
        
        
        [self.cloud4 runAction:self.cloudMoving completion:^{
            
            [self.cloud4 removeFromParent];
            self.cloud4.position  = CGPointMake(1424, 680);
            [self addChild:self.cloud4];
        }];
    }
    if (self.cloud5.position.x < 600){
        
        self.fadeOut = [SKAction fadeAlphaTo:0.0 duration:5];
        self.fadeIn = [SKAction fadeAlphaTo:1.0 duration:2];

        [self.cloud5 runAction:self.fadeOut completion:^{
            
            self.cloud5.position = CGPointMake(1124, 704);
            
            [self.cloud5 runAction: [SKAction group:@[self.fadeIn, self.cloudMoving]]];
                                     
        }];
        
    }
    
    if (self.cloud6.position.x < 700){
        
        self.fadeOut = [SKAction fadeAlphaTo:0.0 duration:5];
        self.fadeIn = [SKAction fadeAlphaTo:1.0 duration:2];
        
        [self.cloud6 runAction:self.fadeOut completion:^{
            
            self.cloud6.position = CGPointMake(1024, 720);
            
            [self.cloud6 runAction: [SKAction group:@[self.fadeIn, self.cloudMoving]]];
            
        }];
    
    }
    

}
-(void)update:(NSTimeInterval)currentTime{
    
    [self checkClouds];
   // self.character.position = CGPointMake(self.touchingPoint.x, 260);
    
    if (self.touchingNuts) {
        self.nuts.position = self.touchingPoint;
    }
    if (self.touchingNuts2) {
        self.nuts2.position = self.touchingPoint;
    }
    if (self.touchingNuts3) {
        self.nuts3.position = self.touchingPoint;
    }
}


@end

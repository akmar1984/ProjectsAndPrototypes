//
//  AppDelegate.h
//  gierka
//
//  Created by Marek Tomaszewski on 27/10/2014.
//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  GameScene4.h
//  gierka
//
//  Created by Marek Tomaszewski on 11/12/2014.
//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene4 : SKScene

@end

//
//  GameSceneTest.m
//  gierka
//
//  Created by Marek Tomaszewski on 13/01/2015.
//  Copyright (c) 2015 CS193p. All rights reserved.
//

#import "GameSceneTest.h"

@implementation GameSceneTest

-(void)didMoveToView:(SKView *)view{
    
    SKShapeNode *kwadrat = (SKShapeNode *)[self childNodeWithName:@"kwadrat"];
    
    

    kwadrat.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:kwadrat.frame.size];
    kwadrat.physicsBody.dynamic = NO;
    kwadrat.fillColor = [SKColor redColor];
    SKSpriteNode *linka = (SKSpriteNode *)[self childNodeWithName:@"linka"];
    
    linka.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:linka.frame.size center:CGPointMake(0, -linka.frame.size.height/2)];
    SKPhysicsJointPin *pineska = [SKPhysicsJointPin jointWithBodyA:kwadrat.physicsBody bodyB:linka.physicsBody anchor:CGPointZero];
    [self.physicsWorld addJoint:pineska];
//    SKPhysicsJointFixed *fixedJoint = [SKPhysicsJointFixed jointWithBodyA:linka.physicsBody bodyB:kwadrat.physicsBody anchor:kwadrat.position];
    
}
@end

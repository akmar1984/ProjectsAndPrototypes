//
//  GameScene2.m
//  gierka
//
//  Created by Marek Tomaszewski on 20/11/2014.
//  Copyright (c) 2014 CS193p. All rights reserved.
//

#import "GameScene2.h"
#import "GameScene3.h"
#import "Stickers.h"
#import "BellBody.h"

@import AVFoundation;
@interface GameScene2 ()

@property SKSpriteNode *bathTub;
@property SKSpriteNode *curtain;
@property SKSpriteNode *sink;
@property SKSpriteNode *toothPaste;
@property SKSpriteNode *mug;
@property SKSpriteNode *mirror;
@property SKSpriteNode *carillon;
@property SKSpriteNode *shower;
@property SKSpriteNode *rope;
@property SKSpriteNode *lightSwitch;
@property SKSpriteNode *backgroundImage;
@property SKSpriteNode *preBackgroundImage;
@property SKSpriteNode *soundIcon;
@property SKSpriteNode *arrow;
@property SKSpriteNode *drops;


@property SKSpriteNode *bubble1;
@property SKSpriteNode *bubble2;
@property SKSpriteNode *bubble3;
@property SKSpriteNode *bubble4;
@property SKSpriteNode *bubble5;
@property SKSpriteNode *bubble6;
@property SKSpriteNode *bubble7;
@property SKSpriteNode *bubble8;
@property SKShapeNode *footer;
@property SKAction *moveUp;
@property SKAction *bubbleSound;
@property NSArray *characterWalkingFrames;
@property SKSpriteNode *tap;
@property SKPhysicsJointPin *pinJoint;
@property SKPhysicsJointPin *pinJointTwo;

@property SKEmitterNode *showerDrops;
@property SKEmitterNode *bubbles;
@property SKEmitterNode *oneBubble;
@property SKEmitterNode *secondBubble;
@property SKEmitterNode *thirdBubble;
@property SKEmitterNode *fourthBubble;
@property SKEmitterNode *fifthBubble;
@property SKEmitterNode *littleSparkEmitter;
@property SKEmitterNode *cutEffect;
@property SKEmitterNode *bigSparkEmitter;

@property SKSpriteNode *spiderRope;
@property SKSpriteNode *spiderRopeTwo;

@property AVAudioPlayer *backgroundMusicPlayer;
#pragma mark BOOLs

@property BOOL lightSwitchStatus;
@property BOOL touchingShower;
@property BOOL touchingCurtain;
@property BOOL musicOn;
@property BOOL touchingToothPaste;
@property BOOL touchingMug;
@property BOOL toothPasteActive;
@property BOOL mugActive;

@property CGPoint touchingPoint;
@property CGPoint originalPosition;

@property CGPoint lightSwitchYOriginalPosition;
@property CGPoint lightTouchingPoint;
@property CGPoint touchStartPoint;
@property CGPoint touchEndPoint;
@property CGFloat bubblesCounter;
@property CGFloat bubbleRestitution;

@property Stickers *stickerOne;
@property SKNode *stickerOneNode;
@property BellBody *bellBodyObject;

@property NSArray *showerDropsFrames;

@end

static const int BODY_OFFSET = 100;

@implementation GameScene2


-(void)didMoveToView:(SKView *)view {
    // [self setupLevel2];
    self.lightSwitchStatus = NO;
    // self.touchingCurtain = NO;
    [self preSetup];
    self.bubbleRestitution = 0.2;
}


-(void)preSetup{
    
    
    
    
    self.lightSwitchYOriginalPosition = CGPointMake(7.25, 578);
    self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];
    self.physicsWorld.gravity = CGVectorMake(0, 0.5);
    
    self.preBackgroundImage = [SKSpriteNode spriteNodeWithImageNamed:@"tlo 2048 lazienka swiatlo zgaszone"];
    self.preBackgroundImage.position = CGPointMake(self.size.width/2, self.size.height/2);
    
    
    [self setupLightSwitch];
    [self addChild:self.preBackgroundImage];
    
   // [self setupSpider];
 //   [self setupSecondSpider];
    
}

-(void)setupSecondSpider{
    SKShapeNode *rect = [SKShapeNode shapeNodeWithRectOfSize:CGSizeMake(30, 30)];
    rect.position = CGPointMake(self.size.width/2+300, self.size.height/2+400);
    rect.fillColor = [SKColor blueColor];
    rect.zPosition = 100;
    rect.physicsBody.dynamic = NO;
    rect.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:rect.frame.size];
    [self addChild:rect];
    
    
    
    self.spiderRopeTwo = [SKSpriteNode spriteNodeWithImageNamed:@"spiderRope"];
    self.spiderRopeTwo.name = @"spiderRope";
    self.spiderRopeTwo.anchorPoint = CGPointMake(0.5, 1);
    self.spiderRopeTwo.position = CGPointZero;
    
    
    self.spiderRopeTwo.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:self.spiderRopeTwo.frame.size center:CGPointMake(0.5, -self.spiderRopeTwo.frame.size.height/2)];
    //center:CGPointMake(0.5, -spider.frame.size.height/2)];
    // spider.zRotation = -M_PI/4;
    
    
    self.spiderRopeTwo.physicsBody.restitution = 0.2;
    self.spiderRopeTwo.physicsBody.mass = 0.2;
    [rect addChild:self.spiderRopeTwo];
    SKPhysicsJointFixed *fixedJoint = [SKPhysicsJointFixed jointWithBodyA:rect.physicsBody bodyB:self.physicsBody anchor:CGPointMake(rect.position.x, self.frame.size.height)];
    
    [self.physicsWorld addJoint:fixedJoint];
    //moze problem polega na uzyciu fixedjoint w tym samym miejscu co pinjoint ?
    self.pinJointTwo = [SKPhysicsJointPin jointWithBodyA:rect.physicsBody bodyB:self.spiderRopeTwo.physicsBody anchor:rect.position];
    
    [self.physicsWorld addJoint:self.pinJointTwo];
    
    SKSpriteNode *spider = [SKSpriteNode spriteNodeWithImageNamed:@"spiderOnly"];
    //  spider.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:spider.frame.size];
    spider.position = CGPointMake(0, -self.spiderRopeTwo.frame.size.height);
    spider.zPosition = 100;
    [self.spiderRopeTwo addChild:spider];
//    [self.spiderRopeTwo.physicsBody applyForce:CGVectorMake(150, 0) atPoint:CGPointMake(1, -self.spiderRopeTwo.frame.size.height/2)];
    //    SKPhysicsJointPin *pinJoint2 = [SKPhysicsJointPin jointWithBodyA:self.spiderRope.physicsBody bodyB:spider.physicsBody anchor: self.spiderRope.position];
    //    [self.physicsWorld addJoint:pinJoint];
    
    //    [spiderRope.physicsBody applyImpulse:CGVectorMake(200, 0) atPoint:CGPointMake(1, -spiderRope.frame.size.height/2)];
    //use constraints check if everything is correct!
//        SKConstraint *rotationConstraint = [SKConstraint zRotation:[SKRange rangeWithLowerLimit:-M_PI/4 upperLimit:M_PI/4]];
//        self.spiderRopeTwo.constraints = @[rotationConstraint];
}


-(void)setupSpider{
    SKShapeNode *rect = [SKShapeNode shapeNodeWithRectOfSize:CGSizeMake(30, 30)];
    rect.position = CGPointMake(self.size.width/2, self.size.height/2+100);
    rect.fillColor = [SKColor blueColor];
    rect.zPosition = 100;
    rect.physicsBody.dynamic = NO;
    rect.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:rect.frame.size];
    [self addChild:rect];
    
    
    
    self.spiderRope = [SKSpriteNode spriteNodeWithImageNamed:@"spiderRope"];
    self.spiderRope.name = @"spiderRope";
    self.spiderRope.anchorPoint = CGPointMake(0.5, 1);
    self.spiderRope.position = CGPointZero;
    
    
    self.spiderRope.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:self.spiderRope.frame.size center:CGPointMake(0.5, -self.spiderRope.frame.size.height/2)];
    //center:CGPointMake(0.5, -spider.frame.size.height/2)];
    // spider.zRotation = -M_PI/4;
    
    
    self.spiderRope.physicsBody.restitution = 0.2;
    self.spiderRope.physicsBody.mass = 0.2;
    [rect addChild:self.spiderRope];
    SKPhysicsJointFixed *fixedJoint = [SKPhysicsJointFixed jointWithBodyA:rect.physicsBody bodyB:self.physicsBody anchor:CGPointZero];
    
    [self.physicsWorld addJoint:fixedJoint];
    
    self.pinJoint = [SKPhysicsJointPin jointWithBodyA:rect.physicsBody bodyB:self.spiderRope.physicsBody anchor:rect.position];
    
    [self.physicsWorld addJoint:self.pinJoint];
    
    SKSpriteNode *spider = [SKSpriteNode spriteNodeWithImageNamed:@"spiderOnly"];
    //  spider.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:spider.frame.size];
    spider.position = CGPointMake(0, -self.spiderRope.frame.size.height);
    spider.zPosition = 100;
    [self.spiderRope addChild:spider];
    [self.spiderRope.physicsBody applyForce:CGVectorMake(50, 0) atPoint:CGPointMake(1, -self.spiderRope.frame.size.height/2)];
    //    SKPhysicsJointPin *pinJoint2 = [SKPhysicsJointPin jointWithBodyA:self.spiderRope.physicsBody bodyB:spider.physicsBody anchor: self.spiderRope.position];
    //    [self.physicsWorld addJoint:pinJoint];
    
    //    [spiderRope.physicsBody applyImpulse:CGVectorMake(200, 0) atPoint:CGPointMake(1, -spiderRope.frame.size.height/2)];
    //use constraints check if everything is correct!
    //    SKConstraint *rotationConstraint = [SKConstraint zRotation:[SKRange rangeWithLowerLimit:-M_PI/4 upperLimit:M_PI/4]];
    //    //self.spiderRope.constraints = @[rotationConstraint];
}
-(void)setupFooter{
    
    self.footer = [SKShapeNode shapeNodeWithRectOfSize:CGSizeMake(1024, 70)];
    
    self.footer.fillColor = [SKColor whiteColor];
    
    self.footer.position = CGPointMake(512, 50);
    //  self.footer.physicsBody = [SKPhysicsBody bodyWithEdgeFromPoint:CGPointMake(0, 120) toPoint:CGPointMake(size.width, 120)];
    
    [self addChild:self.footer];
    
    
}
-(void)setupLevel2{
    
   
    
    [self.preBackgroundImage removeFromParent];
    
    [self playBackgroundMusic:@"BathroomWaterMusic.mp3"];
    self.bubbleSound = [SKAction playSoundFileNamed:@"Bell Bubbles SFX.mp3" waitForCompletion:NO];
    self.musicOn = YES;
    [self.backgroundMusicPlayer play];
    [self setupBackground];
    [self setupBathTubWithShower];
    
    //[self setupLightSwitch];
    [self setupFullSink];
    [self setupMirror];
    
    [self setupFooter];
    [self setupSoundIcon];
    [self setupArrow];
    
    self.stickerOneNode = [SKNode node];
    self.stickerOne = [[Stickers alloc]initStickerWithPosition:CGPointMake(0, 768)andStickerFormsPosition:CGPointMake(130, 50)];
    
    [self.stickerOneNode addChild:self.stickerOne];
    [self addChild:self.stickerOneNode];
    [self setupCharacter];
    
}
-(void)setupSoundIcon{
    self.soundIcon = [SKSpriteNode spriteNodeWithImageNamed:@"glosnik"];
    self.soundIcon.position = CGPointMake(self.soundIcon.size.width, self.size.height-self.soundIcon.size.height);
    [self addChild:self.soundIcon];
    
}
-(void)setupArrow{
    self.arrow = [SKSpriteNode spriteNodeWithImageNamed:@"arrowRight"];
    self.arrow.position = CGPointMake(self.size.width-self.arrow.size.width/2, self.arrow.size.height);
    [self addChild:self.arrow];
    
}
-(void)setupBubble1{
    
    self.bubble1 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaSmallEdited"];
    self.bubble1.position = CGPointMake(700 - arc4random()%10, self.size.height/2);
    self.bubble1.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble1.size.width/2];
    self.bubble1.physicsBody.restitution = self.bubbleRestitution;
    self.bubble1.physicsBody.friction = 0;
    self.bubble1.physicsBody.density = 10.0;
    
    
    
    SKAction *rotate = [SKAction rotateByAngle:M_PI_4 duration:3];
    [self addChild:self.bubble1];
    [self.bubble1 runAction:rotate];
    
}
-(void)setupBubble2{
    self.bubble2 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaEdited"];
    self.bubble2.position = CGPointMake(600 - arc4random()%50, self.size.height/2);
    self.bubble2.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble1.size.width/2];
    self.bubble2.physicsBody.restitution = self.bubbleRestitution;
    self.bubble2.physicsBody.friction = 0;
    self.bubble2.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:-M_PI duration:3];
    [self addChild:self.bubble2];
    [self.bubble2 runAction:rotate];
}
-(void)setupBubble3{
    self.bubble3 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaEdited"];
    self.bubble3.position = CGPointMake(600 - arc4random()%50, self.size.height/2);
    self.bubble3.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble3.size.width/2];
    self.bubble3.physicsBody.restitution = self.bubbleRestitution;
    self.bubble3.physicsBody.friction = 0;
    self.bubble3.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:-M_PI duration:3];
    [self addChild:self.bubble3];
    [self.bubble3 runAction:rotate];
}
-(void)setupBubble4{
    
    self.bubble4 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaSmallEdited"];
    self.bubble4.position = CGPointMake(600 - arc4random()%50, self.size.height/2);
    self.bubble4.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble4.size.width/2];
    self.bubble4.physicsBody.restitution = self.bubbleRestitution;
    self.bubble4.physicsBody.friction = 0;
    self.bubble4.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:-M_PI duration:3];
    [self addChild:self.bubble4];
    [self.bubble4 runAction:rotate];
}
-(void)setupBubble5{
    self.bubble5 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaSmallEdited"];
    self.bubble5.position = CGPointMake(600 - arc4random()%50, self.size.height/2);
    self.bubble5.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble5.size.width/2];
    self.bubble5.physicsBody.restitution = self.bubbleRestitution;
    self.bubble5.physicsBody.friction = 0;
    self.bubble5.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:M_PI_2 duration:3];
    [self addChild:self.bubble5];
    [self.bubble5 runAction:rotate];
}

-(void)setupBubble6{
    self.bubble6 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaEdited"];
    self.bubble6.position = CGPointMake(600 - arc4random()%50, self.size.height/2);
    self.bubble6.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble6.size.width/2];
    self.bubble6.physicsBody.restitution = self.bubbleRestitution;
    self.bubble6.physicsBody.friction = 0;
    self.bubble6.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:-M_PI_4 duration:3];
    [self addChild:self.bubble6];
    [self.bubble6 runAction:rotate];
    
}

-(void)setupBubble7{
    self.bubble7 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaTinyEdited"];
    self.bubble7.position = CGPointMake(800 - arc4random()%50, self.size.height/2);
    self.bubble7.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble7.size.width/2];
    self.bubble7.physicsBody.restitution = self.bubbleRestitution;
    self.bubble7.physicsBody.friction = 0;
    self.bubble7.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:M_PI duration:3];
    [self addChild:self.bubble7];
    [self.bubble7 runAction:rotate];
}

-(void)setupBubble8{
    self.bubble8 = [SKSpriteNode spriteNodeWithImageNamed:@"bankaTinyEdited"];
    self.bubble8.position = CGPointMake(800 - arc4random()%50, self.size.height/2);
    self.bubble8.physicsBody = [SKPhysicsBody bodyWithCircleOfRadius:self.bubble8.size.width/2];
    self.bubble8.physicsBody.restitution = self.bubbleRestitution;
    self.bubble8.physicsBody.friction = 0;
    self.bubble8.physicsBody.density = 10.0;
    
    
    SKAction *rotate = [SKAction rotateByAngle:-M_PI duration:3];
    [self addChild:self.bubble8];
    [self.bubble8 runAction:rotate];
}
/*
 -(void)createBubbles{
 
 [self runAction: [SKAction repeatAction:[SKAction sequence:@[[SKAction performSelector:@selector(setupBubblesSprites)onTarget:self],[SKAction waitForDuration:3]
 ]]count:10]];
 }
 */
- (void)playBackgroundMusic:(NSString *)filename
{
    
    NSError *error;
    NSURL *backgroundMusicURL = [[NSBundle mainBundle] URLForResource:filename withExtension:nil];
    self.backgroundMusicPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:backgroundMusicURL error:&error];
    self.backgroundMusicPlayer.numberOfLoops = -1;
    self.backgroundMusicPlayer.volume = 0.5;
    [self.backgroundMusicPlayer prepareToPlay];
}

-(void)setupCharacter{
    
    
    _bellBodyObject = [[BellBody alloc]initBellWithBodyandHeadInPosition:CGPointMake(self.sink.size.width/2 +240, self.size.height/3 - 70)];
    SKNode *bellNode = [SKNode node];
    
    [bellNode addChild:_bellBodyObject];
    bellNode.zPosition = 0;
    [self addChild:bellNode];
    
}

#pragma mark TLO
-(void)setupBackground{
    
    SKAction *fadeInTheBackground = [SKAction fadeAlphaTo:1 duration:1];
    
    self.backgroundImage = [SKSpriteNode spriteNodeWithImageNamed:@"lazienka tlo"];
    self.backgroundImage.position = CGPointMake(CGRectGetMidX(self.frame), CGRectGetMidY(self.frame));
    self.backgroundImage.zPosition = -2;
    self.backgroundImage.alpha = 0;
    [self addChild:self.backgroundImage];
    
    [self.backgroundImage runAction:fadeInTheBackground];
    self.lightSwitchStatus = NO;
    
}
-(void)setupLightSwitch{
    self.lightSwitch = [SKSpriteNode spriteNodeWithImageNamed:@"sznurek3"];
    self.lightSwitch.position = CGPointMake(self.lightSwitch.size.width/2, 578);
    self.lightSwitch.zPosition = 1;
    self.lightSwitch.anchorPoint = CGPointZero;
    [self addChild:self.lightSwitch];
}

-(void)setupBathTubWithShower{
    self.bathTub = [SKSpriteNode spriteNodeWithImageNamed:@"wanna22"];
    self.bathTub.position = CGPointMake(self.size.width - 310, self.size.height/3 -50);
    self.bathTub.zPosition = 0;
    
    self.shower = [SKSpriteNode spriteNodeWithImageNamed:@"prysznic"];
    self.shower.position = CGPointMake(self.bathTub.position.x - 190, self.bathTub.position.y + 180);
    
    [self addChild:self.shower];
    self.rope = [SKSpriteNode spriteNodeWithImageNamed:@"walek"];
    self.rope.zPosition = 0;
    self.rope.position = CGPointMake(self.bathTub.position.x - 30, self.size.height-170);
    
    
    self.curtain = [SKSpriteNode spriteNodeWithImageNamed:@"kurtynaDuza"];
    self.curtain.position = CGPointMake(self.rope.position.x + 90, 440);
    self.curtain.zPosition = 2;
    
    [self addChild:self.curtain];
    [self addChild:self.rope];
    
    [self addChild:self.bathTub];
    
    
}
-(void)setupBubbleEmitter{
    self.bubbles = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"Bubbles" ofType:@"sks"]];
    self.bubbles.position = CGPointMake(self.size.width - 310, self.size.height/3 + 20);
    self.bubbles.zPosition = 1;
    [self addChild:self.bubbles];

}

-(void)setupFullSink{
    self.sink = [SKSpriteNode spriteNodeWithImageNamed:@"zlewDol"];
    self.sink.position = CGPointMake(self.sink.size.width/2 +50, self.size.height/3 -50);
    self.sink.zPosition = -1;
    self.tap = [SKSpriteNode spriteNodeWithImageNamed:@"kran"];
    self.tap.position = CGPointMake(self.sink.size.width/2 +50, self.size.height/3 +70);
    self.tap.zPosition = -1;
    
    
    
    self.toothPaste = [SKSpriteNode spriteNodeWithImageNamed:@"toothPaste"];
    self.toothPaste.position = CGPointMake(self.sink.position.x - 60, self.sink.position.y+65);
    self.toothPasteActive = YES;
    self.toothPaste.zPosition = 302;
    self.mug = [SKSpriteNode spriteNodeWithImageNamed:@"toothbrushMug"];
    self.mug.position = CGPointMake(self.sink.position.x + 80, self.sink.position.y+135);
    self.mugActive = YES;
    self.mug.zPosition = 302;
    [self addChild:self.mug];
    [self addChild:self.toothPaste];
    [self addChild:self.sink];
    [self addChild:self.tap];
    
}

-(void)setupMirror{
    self.mirror = [SKSpriteNode spriteNodeWithImageNamed:@"Lustro"];
    self.mirror.position = CGPointMake(self.sink.size.width/2 +50, self.size.height/2 +90);
    self.mirror.zPosition = -1;
    [self addChild:self.mirror];
}
- (void)showSoundButtonForTogglePosition:(BOOL)togglePosition
{
    if (togglePosition)
    {
        self.soundIcon.texture = [SKTexture textureWithImageNamed:@"glosnik2"];
        self.musicOn = NO;
        [_backgroundMusicPlayer stop];
    }
    else
    {
        self.soundIcon.texture = [SKTexture textureWithImageNamed:@"glosnik"];
        self.musicOn = YES;
        [_backgroundMusicPlayer play];
    }
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    SKAction *wait = [SKAction waitForDuration:1];
    
    
    for (UITouch * touch in touches) {
        CGPoint location = [touch locationInNode:self];
        [_bellBodyObject moveHeadTowards:location];

        self.touchStartPoint = [touch locationInNode:self];
//        self.littleSparkEmitter = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"LittleSpark" ofType:@"sks"]];
//        self.littleSparkEmitter.zPosition = 100;
//        self.littleSparkEmitter.position = location;
//        
//        [self addChild:self.littleSparkEmitter];
        
         [self.spiderRopeTwo.physicsBody applyImpulse:CGVectorMake(150, 0) atPoint:CGPointMake(1, -self.spiderRopeTwo.frame.size.height/2)];

        
        
        if ([self.soundIcon containsPoint:location]){
            
            [self showSoundButtonForTogglePosition:self.musicOn];
        }
        
        if ([self.arrow containsPoint:location]) {
            
            SKView * skView = (SKView *)self.view;
            skView.showsFPS = YES;
            skView.showsNodeCount = YES;
            /* Sprite Kit applies additional optimizations to improve rendering performance */
            skView.ignoresSiblingOrder = YES;
            [self.backgroundMusicPlayer stop];
            // Create and configure the scene.
            SKScene *gameScene3 = [[GameScene3 alloc]initWithSize:self.size];
            gameScene3.scaleMode = SKSceneScaleModeAspectFill;
            
            SKTransition *transition = [SKTransition fadeWithColor:[UIColor blackColor] duration:3];
            // Present the scene.
            [self.view presentScene:gameScene3 transition:transition];
            
            
            
        }
        
        
        if ([self.curtain containsPoint:location]) {
            
            if (!self.touchingCurtain){
                self.touchingCurtain = YES;
                [self.curtain removeFromParent];
                self.curtain = [SKSpriteNode spriteNodeWithImageNamed:@"kurtynaMala2"];
                self.curtain.position = CGPointMake(self.rope.position.x + 190, 440);
                self.curtain.zPosition = 2;
                [self addChild:self.curtain];
            }
        }
        
        SKTexture *bubbleBurst = [SKTexture textureWithImageNamed:@"bankaWybuchEdited"];
        SKAction *bubbleExplosion = [SKAction fadeOutWithDuration:0.2];
        if ([self.bubble1 containsPoint:location]) {
            
            [self.bubble1 setTexture:bubbleBurst];
            [self.bubble1 runAction:self.bubbleSound];
            [self.bubble1 runAction:bubbleExplosion completion:^{
                
                [self.bubble1 removeFromParent];
                [self runAction:wait completion:^{
                    self.bubblesCounter++;
                    [self setupBubble1];}];
            }];
            
        }
        if ([self.bubble2 containsPoint:location]) {
            
            [self.bubble2 setTexture:bubbleBurst];
            [self.bubble2 runAction:self.bubbleSound];
            
            [self.bubble2 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble2 removeFromParent];
                [self runAction:wait completion:^{
                    
                    
                    [self setupBubble2];}];
                
            }];
            
        }
        if ([self.bubble3 containsPoint:location]) {
            
            [self.bubble3 setTexture:bubbleBurst];
            [self.bubble3 runAction:self.bubbleSound];
            
            [self.bubble3 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble3 removeFromParent];
                [self runAction:wait completion:^{
                    
                    [self setupBubble3];}];
                
            }];
            
        }
        if ([self.bubble4 containsPoint:location]) {
            
            [self.bubble4 setTexture:bubbleBurst];
            [self.bubble4 runAction:self.bubbleSound];
            
            [self.bubble4 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble4 removeFromParent];
                [self runAction:wait completion:^{
                    
                    [self setupBubble4];}];
                
            }];
            
        }
        if ([self.bubble5 containsPoint:location]) {
            
            [self.bubble5 setTexture:bubbleBurst];
            [self.bubble5 runAction:self.bubbleSound];
            
            [self.bubble5 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble5 removeFromParent];
                [self runAction:wait completion:^{
                    
                    [self setupBubble5];}];
                
            }];
            
        }
        if ([self.bubble6 containsPoint:location]) {
            
            [self.bubble6 setTexture:bubbleBurst];
            [self.bubble6 runAction:self.bubbleSound];
            
            [self.bubble6 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble6 removeFromParent];
                [self runAction:wait completion:^{
                    
                    [self setupBubble6];}];
                
            }];
            
        }
        if ([self.bubble7 containsPoint:location]) {
            
            [self.bubble7 setTexture:bubbleBurst];
            [self.bubble7 runAction:self.bubbleSound];
            
            [self.bubble7 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble7 removeFromParent];
                [self runAction:wait completion:^{
                    
                    [self setupBubble7];}];
                
            }];
            
        }
        if ([self.bubble8 containsPoint:location]) {
            
            [self.bubble8 setTexture:bubbleBurst];
            [self.bubble8 runAction:self.bubbleSound];
            
            [self.bubble8 runAction:bubbleExplosion completion:^{
                self.bubblesCounter++;
                [self.bubble8 removeFromParent];
                [self runAction:wait completion:^{
                    
                    [self setupBubble8];}];
                
            }];
            
        }
        if ([self.shower containsPoint:location] && !self.touchingShower) {
            
            self.touchingShower = YES;
            
            SKAction *wait = [SKAction waitForDuration:2];
            
            SKAction *wait2 = [SKAction waitForDuration:1];
            
            SKAction *wait3 = [SKAction waitForDuration:3];
            
            SKAction *wait4 = [SKAction waitForDuration:4];
            
            SKTexture *bathTubeFullTexture = [SKTexture textureWithImageNamed:@"wanna2woda"];
            SKAction *remove = [SKAction removeFromParent];
            SKAction *setBathTubeTexture = [SKAction setTexture:bathTubeFullTexture];
            
            [self startTheWaterAnimation];
            
            SKAction *block1 =[SKAction runBlock:^{
                [self runAction:wait2 completion:^{
                    [self setupBubble1];
                    
                    [self runAction:[SKAction waitForDuration:1] completion:^{
                        [self setupBubble8];
                        
                    }];
                    
                }];
                
                
            }];
            
            SKAction *block2 =[SKAction runBlock:^{
                [self runAction:wait3 completion:^{
                    [self setupBubble2];
                    
                    [self runAction:[SKAction waitForDuration:1] completion:^{
                        [self setupBubble6];
                        
                    }];
                    
                }];
                
            }];
            SKAction *block3 =[SKAction runBlock:^{
                [self runAction:wait4 completion:^{
                    [self setupBubble3];
                    
                    
                    [self runAction:[SKAction waitForDuration:4] completion:^{
                        [self setupBubble7];
                        
                    }];
                    
                }];
                
            }];
            
            SKAction *block4 =[SKAction runBlock:^{
                [self runAction:wait completion:^{
                    [self setupBubble4];
                    [self runAction:[SKAction waitForDuration:2] completion:^{
                        [self setupBubble5];
                        
                    }];
                }];
                
            }];
            
            [self.drops runAction:[SKAction sequence:@[wait, remove]] completion:^{
                
                
                [self runAction:[SKAction sequence:@[block1, block2, block3, block4]]];
                
                
            }];
            
            
            
            if (self.touchingShower) {
                
                
                
                [self.bathTub runAction:[SKAction sequence:@[wait, setBathTubeTexture]]];
                
                [self.bathTub runAction:wait completion:^{
                    [self setupBubbleEmitter];
                    // self.touchingShower = NO;
                    // [self setupSingleBubbles];
                }];
                
                
                
            }
            
            
            
        }
        
        
        if ([self.lightSwitch containsPoint:location]){
            
            [self.lightSwitch runAction:[SKAction playSoundFileNamed:@"Wlacznik SFX.mp3" waitForCompletion:NO]];
            self.lightSwitchStatus = YES;
            self.lightTouchingPoint = location;
        }
        
        if ([self.toothPaste containsPoint:location] && self.toothPasteActive == YES) {
            self.originalPosition = self.toothPaste.position;

            self.touchingToothPaste = YES;
            self.touchingPoint = location;
        }
        if ([self.mug containsPoint:location] && self.mugActive == YES) {
            self.originalPosition = self.mug.position;
           
            self.touchingMug = YES;
            self.touchingPoint = location;
        }
        
    }
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    
    for (UITouch *touch in touches){
        
        CGPoint location = [touch locationInNode:self];
        CGPoint newLocation = CGPointMake(self.lightSwitch.position.x, location.y);
        
        self.touchingPoint = [[touches anyObject]locationInNode:self];
        
        self.cutEffect = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"cutEffect" ofType:@"sks"]];
        self.cutEffect.position = location;
        [self addChild:self.cutEffect];
        
       
        if (self.lightSwitchStatus) {
            self.lightSwitch.position = newLocation;
            
            if (newLocation.y < self.lightSwitchYOriginalPosition.y - 100) {
                
                newLocation.y = self.lightSwitchYOriginalPosition.y - 100;
            }
            
            
            self.lightSwitch.position = newLocation;
            
        }
        
    }
    
    
    //[self setupLevel2];
    
    
}
-(void)setupCharacterHappyAnimation{
    
    SKAction *wiggleTailUp = [SKAction rotateByAngle:M_PI_4/16 duration:0.2];
    SKAction *wiggleTailDown = [SKAction rotateByAngle:-M_PI_4/16 duration:0.2];
    SKAction *wiggling = [SKAction repeatAction:[SKAction sequence:@[wiggleTailUp, wiggleTailDown]] count:7];
    SKAction *wiggleHeadUp = [SKAction rotateByAngle:M_PI_4/16 duration:0.3];
    SKAction *wiggleHeadDown = [SKAction rotateByAngle:-M_PI_4/16 duration:0.3];
    SKAction *wigglingHead = [SKAction repeatAction:[SKAction sequence:@[wiggleHeadDown, wiggleHeadUp]] count:5];

    [_bellBodyObject.bellsBody runAction:wiggling];
    [_bellBodyObject.bellsHead runAction:wigglingHead];
    
    
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{

    NSLog(@"%f", self.bubblesCounter);
    if (self.touchingShower) {
        
        if (self.bubblesCounter == 3) {
            //run the animation here
            [self.stickerOne runStickerAnimation:self.stickerOne.stickerStarOne];
            [self setupCharacterHappyAnimation];
            
        }
        
    }
    
    
    if (self.touchingToothPaste && self.toothPasteActive == YES) {
        CGPoint currentPoint = [[touches anyObject] locationInNode:self];
        CGPoint finalPos = _bellBodyObject.bellsBody.position;

        if ([self isWithinCharactersBody:currentPoint])
        {
         
            self.toothPaste.position = CGPointMake(finalPos.x-70, finalPos.y+10);
            self.toothPaste.zRotation = M_PI-M_PI_4;
            self.touchingToothPaste = NO;
            self.toothPasteActive = NO;
           
            [self setupBigSparkEmiter:currentPoint];
            [self.stickerOne runStickerAnimation:self.stickerOne.stickerStarTwo];
        }else{
            [self animatePuttingThingsBack:self.toothPaste];
            self.touchingToothPaste = NO;
        }
    }
    
    if (self.touchingMug && self.mugActive == YES) {
        CGPoint currentPoint = [[touches anyObject] locationInNode:self];
        CGPoint finalPos = _bellBodyObject.bellsBody.position;
        
        if ([self isWithinCharactersBody:currentPoint])
        {
            
            self.mug.position = CGPointMake(finalPos.x+70, finalPos.y+20);
            self.mug.zRotation = -M_PI/8;
            self.touchingMug = NO;
            self.mugActive = NO;
           
            [self setupBigSparkEmiter:currentPoint];
            [self.stickerOne runStickerAnimation:self.stickerOne.stickerStarThree];

        }else{
            [self animatePuttingThingsBack:self.mug];
            self.touchingMug = NO;

        }
    }
    
    
    if (self.lightSwitch.position.y < 550 && (self.lightSwitchStatus == YES)){
        self.moveUp = [SKAction moveToY: 758 duration:0.5];
        [self.lightSwitch runAction:self.moveUp];
        self.lightSwitchStatus = NO;
        [self setupLevel2];
        
    }
    
    
}
//-(void)setupShowerDrops{
//    
//    self.bubblesCounter = 0;
//    self.showerDrops = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"Water" ofType: @"sks"]];
//    self.showerDrops.zPosition = 1;
//    // self.trail.targetNode = self;
//    self.showerDrops.position = CGPointMake(self.shower.position.x+50, self.shower.position.y+50);
//    
//    [self addChild:self.showerDrops];
//    
//    
//}
-(void)startTheWater{
    
}
-(void)startTheWaterAnimation{
    
   NSMutableArray *dropFrames = [NSMutableArray array];
    [dropFrames addObject:[SKTexture textureWithImageNamed:@"woda prysznic1"]];
    [dropFrames addObject:[SKTexture textureWithImageNamed:@"woda prysznic2"]];
    [dropFrames addObject:[SKTexture textureWithImageNamed:@"woda prysznic3"]];


    self.showerDropsFrames = dropFrames;
    
  
    self.drops = [SKSpriteNode spriteNodeWithTexture:self.showerDropsFrames[0]];
    self.drops.zPosition = 1;
    self.drops.position = CGPointMake(self.shower.position.x+70, self.shower.position.y-30);
    
    [self addChild:self.drops];
    
        [self.drops runAction:[SKAction repeatAction:[SKAction animateWithTextures:self.showerDropsFrames
                                                                      timePerFrame:0.1f
                                                                            resize:NO
                                                                            restore:YES] count:30]completion:^{
    
            [self.drops removeFromParent];
        }];

//    [self.drops runAction:[SKAction repeatAction:[SKAction animateWithTextures:self.showerDropsFrames
//                                                                  timePerFrame:0.05f
//                                                                        resize:NO
//                                                                        restore:YES] count:15]completion:^{
//        
//        [self.drops removeFromParent];
//    }];
    
    
}
-(void)setupBigSparkEmiter:(CGPoint)coordinates{
    
    
    self.bigSparkEmitter = [NSKeyedUnarchiver unarchiveObjectWithFile:[[NSBundle mainBundle]pathForResource:@"BigSpark" ofType:@"sks"]];
    self.bigSparkEmitter.zPosition = 500;
    self.bigSparkEmitter.position = coordinates;
    
    [self addChild:self.bigSparkEmitter];
}
-(BOOL)isWithinCharactersBody:(CGPoint)currentLocation{
    if (currentLocation.x >= _bellBodyObject.bellsBody.position.x - BODY_OFFSET && currentLocation.x <= _bellBodyObject.bellsBody.position.x + BODY_OFFSET && currentLocation.y >= _bellBodyObject.bellsBody.position.y - BODY_OFFSET && currentLocation.y <= _bellBodyObject.bellsBody.position.y + BODY_OFFSET){
        
        return YES;
    }else
        return NO;
}


-(void)animatePuttingThingsBack:(SKSpriteNode *)node
{
    
    SKAction *scaleDown = [SKAction scaleTo:1.0 duration:0.5];
    SKAction *moveLeft = [SKAction moveByX:-10 y:0 duration:0.2];
    SKAction *moveRight = [SKAction moveByX:10 y:0 duration:0.2];
    
    SKAction *fastMovementSeq = [SKAction repeatAction:[SKAction sequence:@[moveLeft, moveRight]] count:4];
    SKAction *moveBack = [SKAction moveTo:self.originalPosition duration: 1];
    SKAction *rotateBack = [SKAction rotateByAngle:M_PI *2 duration:0.5];
    SKAction *group = [SKAction group:@[moveBack, rotateBack]];
    ;
    
    SKAction *seq =[SKAction sequence: @[scaleDown, fastMovementSeq, group]];
    [node runAction:seq];
    
}

-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    self.touchingMug = NO;
    self.touchingToothPaste = NO;
}
-(void)update:(CFTimeInterval)currentTime {
    
    if (self.touchingToothPaste) {
        self.toothPaste.position = self.touchingPoint;
    }

    if (self.touchingMug) {
        self.mug.position = self.touchingPoint;
    }
}

@end
